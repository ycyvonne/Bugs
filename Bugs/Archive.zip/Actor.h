#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "GameConstants.h"

class StudentWorld;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class Actor: public GraphObject{
public:
    Actor(int id, StudentWorld* sw,
          int imageID, int startX, int startY, Direction dir, int depth);
    
    virtual void doSomething() {}
    
    int type() const;
    int id() const;
    bool isBlocked(int x, int y) const;
    bool isInsect() const;
    
    void setRandomDir();
    void setAsInsect();

protected:
    void moveMeTo(int x, int y);
    
private:
    StudentWorld* m_world;
    bool m_isInsect;
    int m_id;
    int m_type;
};

class Pebble: public Actor{
public:
    Pebble(int id, StudentWorld* sw, int startX, int startY);
    virtual void doSomething() {}
    
private:
    
    
};

class Insect: public Actor{
public:
    Insect(int id, StudentWorld* sw,
           int imageID, int startX, int startY, Direction dir, int startingHealth, int stuns);
    
    //overrides base
    virtual void doSomething();
    //mean to be overriden in subclasses
    virtual void doesAction() {}
    
    //accessors
    int health() const;
    bool isDead() const;
    
    //mutators
    void getHungrier();
    void stun();
    void killMe();
    
    
private:
    int m_health;
    int m_stunnedTicksRemaining;
};

class Grasshopper: public Insect{
public:
    Grasshopper(int id, StudentWorld *sw,
                int imageID, int startX, int startY, int health);
    
    //mutators
    virtual void doesAction() {}
    virtual bool makeChecks() {return false;} //if makeChecks returns true, grasshopper will move
    virtual void move();
    
    void setRandomDistance();
    
    //accessors
    int distance();
    
private:
    int m_distance;
    int m_bite;
    
};


class BabyGrasshopper: public Grasshopper{
public:
    BabyGrasshopper(int id, StudentWorld* sw, int startX, int startY);
    
    //mutators
    virtual void doesAction();
    virtual bool makeChecks();
private:
    
};

class AdultGrasshopper: public Grasshopper{
public:
    AdultGrasshopper(int id, StudentWorld* sw, int startX, int startY, int health);
    
    //mutators
    virtual void doesAction();
    virtual bool makeChecks();
private:
    
};

#endif // ACTOR_H_
