#include "StudentWorld.h"
#include "Field.h"
#include "Actor.h"
#include <string>


using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp
StudentWorld::~StudentWorld()
{
    cleanUp();
}

void StudentWorld::cleanUp()
{
    for(int i = 0; i < VIEW_WIDTH; i++)
    {
        for(int j = 0; j < VIEW_HEIGHT; j++)
        {
            indexPair index (i, j);
            while(m_map.count(index) > 0)
            {
                mmap::iterator it = m_map.find(index);
                delete it->second;
                m_map.erase (it);
            }
        }
    }
}

int StudentWorld::init()
{
    m_tickCount = 0;
    m_currentUniqueId = 0;
    
    Field f;
    string fileName = "/Users/yvonne.chen1/Documents/Main/Courses\:School/Q2/CS\ 32/projects/Project3/Bugs/Bugs/field.txt";
   // string fileName = getFieldFilename();
    string error;
    
    if(f.loadField(fileName, error) != Field::load_success){
        cout << error << endl;
        return GWSTATUS_NO_WINNER;
    }
    
    for(int i = 0; i < VIEW_WIDTH; i++)
    {
        for(int j = 0; j < VIEW_HEIGHT; j++)
        {
            Field::FieldItem
            fItem = f.getContentsOf(i, j);
            indexPair index (i, j);
            switch(fItem)
            {
                case Field::rock:
                    m_map.insert(mmapPair(index, new Pebble(m_currentUniqueId++, this, i, j)));
                    break;
                case Field::grasshopper:
                    m_map.insert(mmapPair(index, new BabyGrasshopper(m_currentUniqueId++, this, i, j)));
                    break;
                default:
                    break;
            }
        }
    }
    
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::setDisplayText()
{
    string s = "Ticks: ";
    s += to_string(m_tickCount);
    setGameStatText(s);
}

int StudentWorld::move()
{
    
    for(int i = 0; i < VIEW_HEIGHT; i++)
    {
        for(int j = 0; j < VIEW_WIDTH; j++)
        {
            indexPair index (i, j);
            mmap::iterator it = m_map.equal_range(index).first;
                        
            while(it != m_map.equal_range(index).second)
            {
                Actor *cur = it->second;
                int oldX = cur->getX();
                int oldY = cur->getY();
                
                cur->doSomething();
                
                int newX = cur->getX();
                int newY = cur->getY();
                
                if(oldX != newX || oldY != newY)
                {
                    it = m_map.equal_range(index).first;
                }
                else
                    it++;
                
            }
        }
    }
    
    setDisplayText();
    
    m_tickCount++;
    
    
    //check endgame
    if(m_tickCount >= END_GAME_TICKS)
        return GWSTATUS_NO_WINNER;
    
    return GWSTATUS_CONTINUE_GAME;
}

bool StudentWorld::isBlocked(int x, int y)
{
    indexPair index (x, y);
    mmap::iterator it;
    for(it = m_map.equal_range(index).first; it != m_map.equal_range(index).second; ++it){
        if(it->second->type() == IID_ROCK)
            return true;
    }
    
    return false;
}

void StudentWorld::killActor(int id, int x, int y)
{
    removeActor(true, id, x, y);
}


//depending on deleteMe, will delete Actor* at the location
void StudentWorld::removeActor(bool deleteMe, int id, int x, int y)
{
    indexPair index (x, y);
    mmap::iterator it;
    for (it = m_map.equal_range(index).first; it != m_map.equal_range(index).second; ++it){
        if(it->second->id() == id)
        {
            if(deleteMe)
                delete it->second;
            
            m_map.erase(it);
            return;
        }
    }
}

void StudentWorld::insertActor(Actor* a, int x, int y)
{
    indexPair index (x, y);
    m_map.insert(mmapPair(index, a));
}

bool StudentWorld::moveActor(int id, int xStart, int yStart, int xEnd, int yEnd)
{
    indexPair index (xStart, yStart);
    mmap::iterator it;
    
    for (it = m_map.equal_range(index).first; it != m_map.equal_range(index).second; ++it){
        if(it->second->id() == id)
        {
            Actor* temp = it->second;
            insertActor(temp, xEnd, yEnd);
            removeActor(false, id, xStart, yStart);
            return true;
        }
    }
    
    return false;
}
