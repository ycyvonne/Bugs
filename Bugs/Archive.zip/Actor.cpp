#include "Actor.h"
#include "StudentWorld.h"
#include <iostream>

using namespace std;

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

//==============[ Actor ]=============================================
Actor::Actor(int id, StudentWorld* sw, int imageID, int startX, int startY,
             Direction dir, int depth)
        :GraphObject(imageID, startX, startY, dir, depth, 0.25)
{
    m_world = sw;
    m_id = id;
    m_type = imageID;
    m_isInsect = false;
    setDirection(dir);
}

int Actor::type() const{
    return m_type;
}

int Actor::id() const{
    return m_id;
}

void Actor::setAsInsect(){
    m_isInsect = true;
}

bool Actor::isBlocked(int x, int y) const{
    return m_world->isBlocked(x, y);
}

bool Actor::isInsect() const{
    return m_isInsect;
}

void Actor::setRandomDir()
{
    int randDir = rand() % 4;
    switch(randDir)
    {
        case 0:
            setDirection(up);
            break;
        case 1:
            setDirection(down);
            break;
        case 2:
            setDirection(left);
            break;
        case 3:
            setDirection(right);
            break;
    }
}

void Actor::moveMeTo(int x, int y)
{
    
    cout << "id #: " << id() << " moves to (" << x << ", " << y << ")" << endl;
    
    int thisX = getX();
    int thisY = getY();
    
    //update world
    m_world->moveActor(id(), thisX, thisY, x, y);
    
    //update display
    moveTo(x, y);
}

//==============[ Actor > Pebble ]====================================
//sets depth = 1
Pebble::Pebble(int id, StudentWorld* sw, int startX, int startY)
        :Actor(id, sw, IID_ROCK, startX, startY, right, 1) {}


//==============[ Actor > Insect ]====================================
//sets depth = 1, passes along all other params
Insect::Insect(int id, StudentWorld* sw,
               int imageID, int startX, int startY,
               Direction dir, int startingHealth, int stuns)
        :Actor(id, sw, imageID, startX, startY, dir, 2)
{
    m_health = startingHealth;
    m_stunnedTicksRemaining = stuns;
    setAsInsect();
}

int Insect::health() const
{
    return m_health;
}

bool Insect::isDead() const
{
    return m_health <= 0;
}

void Insect::getHungrier()
{
    m_health--;
}

void Insect::stun()
{
    m_stunnedTicksRemaining = 2;
}

void Insect::killMe()
{
    setVisible(false);
}

void Insect::doSomething()
{
    getHungrier();
    
    if(isDead())
        killMe();
    
    if(m_stunnedTicksRemaining > 0)
    {
        m_stunnedTicksRemaining--;
        return;
    }
    m_stunnedTicksRemaining = 2;
    
    doesAction();
    
}

//==============[ Actor > Insect > Grasshopper ]==========================
//sets stuns = 0
Grasshopper::Grasshopper(int id, StudentWorld *sw, int imageID, int startX, int startY, int health)
        :Insect(id, sw, imageID, startX, startY, right, health, 0)
{
    setRandomDistance();
    setRandomDir();
    m_bite = 0; //adult is 50
}

int Grasshopper::distance()
{
    return m_distance;
}

void Grasshopper::setRandomDistance()
{
    m_distance = rand() % 9 + 2; //between [2, 10]
}

void Grasshopper::move()
{
    if(makeChecks()){

        int x = getX();
        int y = getY();
        switch(getDirection())
        {
            case up:
                y--;
                break;
            case down:
                y++;
                break;
            case left:
                x--;
                break;
            case right:
                x++;
                break;
            default:
                break;
                
        }
        
        if(isBlocked(x, y))
        {
            m_distance = 0;
            stun();
            return;
        }
        
        moveMeTo(x, y);
        
        m_distance--;
    }
}


//==============[ Actor > Insect > Grasshopper > BabyGrasshopper ]========
//sets imageID, health = 500
BabyGrasshopper::BabyGrasshopper(int id, StudentWorld *sw, int startX, int startY)
        :Grasshopper(id, sw, IID_BABY_GRASSHOPPER, startX, startY, 500)
{ cout << "init baby grasshopper" << endl;}

void BabyGrasshopper::doesAction()
{
    if(health() >= 1600)
    {
        //create adult
        //AdultGrasshopper(getX(), getY(), 1, health());
        
        killMe();
        return;
    }
    
    //attempts to eat up to 200 units
    /*
     if(square has food)
     {
        //eats
        int rand = rand() % 2;
        if(rand == 0){
            stun();
            return;
        }
     }
     */
    
    move();
    
}

bool BabyGrasshopper::makeChecks()
{
    if(distance() <= 0)
    {
        setRandomDir();
        setRandomDistance();
        return false;
    }
    
    return true;
}

//==============[ Actor > Insect > Grasshopper > AdultGrasshopper ]========
AdultGrasshopper::AdultGrasshopper(int id, StudentWorld* sw, int startX, int startY, int health)
        :Grasshopper(id, sw, IID_BABY_GRASSHOPPER, startX, startY, health)
{
    
}

void AdultGrasshopper::doesAction()
{

}

bool AdultGrasshopper::makeChecks()
{
    return false;
}
